/**
 * Automatically generated file. DO NOT MODIFY
 */
package ai.onnxruntime.extensions;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ai.onnxruntime.extensions";
  public static final String BUILD_TYPE = "release";
}
